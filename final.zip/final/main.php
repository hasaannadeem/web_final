<!DOCTYPE html>
<html lang="en">
<head>
	<title>Main Page</title>
<!--	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"> !-->

	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

<style>
#books {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#books td, #books th {
  border: 1px solid #ddd;
  padding: 8px;
}

#books tr:nth-child(even){background-color: #f2f2f2;}

#books tr:hover {background-color: #ddd;}

#books th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

</div>
	<div class="limiter">					
		<div class="container-login100">			
		
			<div class="wrap-login100">			
			<form class="login100-form validate-form" action="" method="POST">
						
					<div class="wrap-input100 validate-input m-t-85 m-b-35" >
						<input class="input100" type="text" name="bookTitle">
						<span class="focus-input100" data-placeholder="Book Title"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-50" >
						<input class="input100" type="text" name="bookAuthor">
						<span class="focus-input100" data-placeholder="Book Author"></span>
					</div>
									

					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Add Record
						</button>
						
					</div>

				</form>
			</div>  
		</div> 
<span class="login100-form-title p-b-70">
					<div style="width:80%; margin:auto;">
						<div style="width:50%; text-align: left; float:left">Welcome  </div> <div style="width:50%; text-align: right; float:left;">Logout</div>
					</div>	
					</span>	
	
	<table id="books" style="width:80%; margin:auto;">
	  <tr>
		<th>ID</th>
		<th>Book Title</th>
		<th>Book Author</th>
		<th>Added By</th>
		<th>Operation</th>
	  </tr>
	  <?php
			
			$con = new mysqli("localhost", "root" ,"", "final");
			$q = "select * from books";
			$rs = $con->query($q);
			
			while($r = $rs->fetch_assoc()){
		echo "<tr>";
		$id = $r["id"];
			echo "<td>" . $r["id"] ."</td>";
			echo "<td>" .$r["booktitle"] ."</td>";
			echo "<td>" . $r["bookauthor"] ."</td>";
			echo "<td>" . $r["addedby"] ."</td>";
			echo "<td><a href=''> Delete </a> / <a href=''> Update </a> </td>";
		echo "</tr>";
	  }
	  ?>
	</table>
		
		
</div> 



	<script src="js/main.js"></script>

</body>
</html>